﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Border_Control
{
    interface IEntry
    {
        string ModelName { get; set; }

        string Id { get; set; }

        bool EndsWithCheck(string endDigits);
    }
}
