﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Border_Control
{
    public class EntryUnits : IEntry
    {
        public string ModelName { get; set; }
        public string Id { get; set; }

        public EntryUnits(string name, string id)
        {
            this.ModelName = name;
            this.Id = id;
        }

        public bool EndsWithCheck(string endDigits)
        {
            if (!this.Id.EndsWith(endDigits))
            {
                return false;
            }

            return true;
        }
    }
}
