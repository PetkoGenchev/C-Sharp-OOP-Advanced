﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Border_Control
{
    public class Program
    {
        static void Main()
        {
            List<EntryUnits> entries = new List<EntryUnits>();

            while (true)
            {
                string input = Console.ReadLine();

                if (input == "End")
                {
                    break;
                }

                var inputArray = input.Split().ToList();

                string name = inputArray[0];
                string id = null;

                if (inputArray.Count == 3)
                {
                     id = inputArray[2];
                }
                else
                {
                     id = inputArray[1];
                }

                var entry = new EntryUnits(name, id);
                entries.Add(entry);

            }

            string endDigits = Console.ReadLine();

            foreach (EntryUnits item in entries)
            {


                if (item.EndsWithCheck(endDigits))
                {
                    Console.WriteLine(item.Id);
                }
            }
        }
    }
}
