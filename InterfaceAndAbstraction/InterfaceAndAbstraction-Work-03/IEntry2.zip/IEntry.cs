﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Border_Control
{
    interface IEntry
    {
        //string Birthday { get; set; }

        //public bool EndsWithCheck(string endDigits)
        //{
        //    if (!this.Birthday.EndsWith(endDigits))
        //    {
        //        return false;
        //    }

        //    return true;
        //}
    }
}
