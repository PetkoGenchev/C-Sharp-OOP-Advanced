﻿using System;

namespace Telephony.GlobalMsg
{
    public class InvalidMsg
    {
        public const string InvalidUrlMsg = "Invalid URL!";

        public const string InvalidNumberMsg = "Invalid number!";

    }
}
