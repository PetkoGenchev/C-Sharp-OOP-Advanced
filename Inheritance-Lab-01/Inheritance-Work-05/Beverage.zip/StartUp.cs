﻿using System;

namespace Restaurant
{
    public class StartUp
    {
        static void Main(string[] args)
        {

        //    var cake = new Cake("Torta",100.10M,300,50000);

        //    Console.WriteLine(cake.Name);
        //    Console.WriteLine(cake.Price);
        //    Console.WriteLine(cake.Grams);
        //    Console.WriteLine(cake.Calories);

        //    var fish = new Fish("Riba", 200.50M, 50000);

        //    Console.WriteLine(fish.Name);
        //    Console.WriteLine(fish.Price);
        //    Console.WriteLine(fish.Grams);

        //    var coffee = new Coffee("Lavaza", 40.35M,11);

        //    Console.WriteLine(coffee.Name);
        //    Console.WriteLine(coffee.Price);
        //    Console.WriteLine(coffee.Milliliters);
        //    Console.WriteLine(coffee.coffeeMilliliters);
        //    Console.WriteLine(coffee.coffeePrice);
        //    Console.WriteLine(coffee.Caffeine);

        }
    }
}
