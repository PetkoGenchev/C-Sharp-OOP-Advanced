﻿using System;

namespace Encapsulation_Work_03
{
    class Program
    {
        static void Main(string[] args)
        {
            Pizza pizza = new Pizza();

            pizza.Run();

        }
    }
}
