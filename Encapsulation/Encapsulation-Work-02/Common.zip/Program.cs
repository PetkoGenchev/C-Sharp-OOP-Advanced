﻿using Encapsulation_Work_02.Core;

namespace Encapsulation_Work_02
{
    class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
