﻿namespace Encapsulation_Work_02
{
    public static class GlobalConstants
    {
        public const string emptyNameException = "Name cannot be empty";

        public const string emptyMoneyException = "Money cannot be negative";
    }
}
