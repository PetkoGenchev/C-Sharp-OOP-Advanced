﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Exceptions
{
    public class WrongFoodTypeExc
    {
        public static string wrong_Food_Exc_Msg = "{0} does not eat {1}!";
    }
}
