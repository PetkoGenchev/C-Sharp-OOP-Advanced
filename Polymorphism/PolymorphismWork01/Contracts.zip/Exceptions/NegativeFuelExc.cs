﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.Exceptions
{
    public static class NegativeFuelExc
    {
        public const string Negative_Fuel_MSG = "Fuel must be a positive number";

    }
}
