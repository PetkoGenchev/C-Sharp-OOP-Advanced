﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public static class InvalidFuelAmountExc
    {

        public const string Invalid_Fuel_Amount_MSG = "Cannot fit {0} fuel in the tank";

    }
}
